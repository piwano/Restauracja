﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Core.Models;
using Infrastructure.Repositories;

namespace WinFormsUI
{
    public class MainForm : Form
    {
        private Label titleLabel;
        private ListBox listBox;
        private Button addFoodButton;
        private Button addDrinkButton;
        private ComboBox drinkComboBox;
        private Label totalLabel;
        private Button removeSelectedButton;
        private ComboBox filterComboBox;

        private IRepository<Food> foodRepository;
        private IRepository<Drink> drinkRepository;

        private List<Drink> availableDrinks = new List<Drink>();

        public MainForm()
        {
            Text = "Restaurant Manager";
            Width = 600;
            Height = 650;

            titleLabel = new Label
            {
                Text = "Twoje zamówienie",
                Top = 10,
                Left = 10,
                Font = new System.Drawing.Font("Arial", 14, System.Drawing.FontStyle.Bold),
                AutoSize = true
            };

            listBox = new ListBox
            {
                Top = 40,
                Left = 10,
                Width = 560,
                Height = 300
            };

            addFoodButton = new Button
            {
                Text = "Dodaj Pizza",
                Top = 360,
                Left = 10
            };

            drinkComboBox = new ComboBox
            {
                Top = 400,
                Left = 10,
                Width = 200
            };

            addDrinkButton = new Button
            {
                Text = "Dodaj Drink",
                Top = 400,
                Left = 220
            };

            removeSelectedButton = new Button
            {
                Text = "Usuń wybraną pozycję",
                Top = 440,
                Left = 10,
                Width = 200
            };

            totalLabel = new Label
            {
                Text = "Suma zamówienia: 0,00 zł",
                Top = 480,
                Left = 10,
                Width = 300,
                Font = new System.Drawing.Font("Arial", 12, System.Drawing.FontStyle.Bold)
            };

            filterComboBox = new ComboBox
            {
                Top = 520,
                Left = 10,
                Width = 200
            };

            filterComboBox.Items.AddRange(new[] { "Wszystko", "Pizze", "Napoje" });
            filterComboBox.SelectedIndex = 0;

            addFoodButton.Click += AddFoodButton_Click;
            addDrinkButton.Click += AddDrinkButton_Click;
            removeSelectedButton.Click += RemoveSelectedButton_Click;
            filterComboBox.SelectedIndexChanged += FilterComboBox_SelectedIndexChanged;

            Controls.Add(titleLabel);
            Controls.Add(listBox);
            Controls.Add(addFoodButton);
            Controls.Add(drinkComboBox);
            Controls.Add(addDrinkButton);
            Controls.Add(removeSelectedButton);
            Controls.Add(totalLabel);
            Controls.Add(filterComboBox);

            // Usunięcie plików JSON, żeby zamówienia były puste przy starcie
            if (System.IO.File.Exists("foods.json"))
                System.IO.File.Delete("foods.json");

            if (System.IO.File.Exists("drinks.json"))
                System.IO.File.Delete("drinks.json");

            foodRepository = new JsonRepository<Food>("foods.json");
            drinkRepository = new JsonRepository<Drink>("drinks.json");

            LoadDrinks();
            LoadData();
        }

        private void LoadData()
        {
            listBox.Items.Clear();

            var selectedFilter = filterComboBox?.SelectedItem?.ToString();

            if (selectedFilter == "Pizze" || selectedFilter == "Wszystko")
            {
                foreach (var food in foodRepository.GetAll())
                {
                    listBox.Items.Add(food.GetDescription());
                }
            }

            if (selectedFilter == "Napoje" || selectedFilter == "Wszystko")
            {
                foreach (var drink in drinkRepository.GetAll())
                {
                    listBox.Items.Add(drink.GetDescription());
                }
            }

            UpdateTotal();
        }

        private void LoadDrinks()
        {
            availableDrinks = new List<Drink>
            {
                new Drink { Id = 1, Name = "Cola", IsAlcoholic = false, Price = 8.0m },
                new Drink { Id = 2, Name = "Piwo", IsAlcoholic = true, Price = 12.0m },
                new Drink { Id = 3, Name = "Woda", IsAlcoholic = false, Price = 5.0m }
            };

            drinkComboBox.DataSource = availableDrinks;
            drinkComboBox.DisplayMember = "DisplayText";
        }

        private void AddFoodButton_Click(object sender, EventArgs e)
        {
            using var pizzaForm = new PizzaForm();
            if (pizzaForm.ShowDialog() == DialogResult.OK)
            {
                var newPizza = pizzaForm.SelectedPizza;
                foodRepository.Add(newPizza);
                foodRepository.Save();
                LoadData();
            }
        }

        private void AddDrinkButton_Click(object sender, EventArgs e)
        {
            if (drinkComboBox.SelectedItem is Drink selectedDrink)
            {
                var newDrink = new Drink
                {
                    Id = new Random().Next(1, 1000),
                    Name = selectedDrink.Name,
                    Price = selectedDrink.Price,
                    IsAlcoholic = selectedDrink.IsAlcoholic
                };

                drinkRepository.Add(newDrink);
                drinkRepository.Save();
                LoadData();
            }
        }

        private void RemoveSelectedButton_Click(object sender, EventArgs e)
        {
            if (listBox.SelectedItem == null)
            {
                MessageBox.Show("Nie wybrano żadnej pozycji do usunięcia.", "Informacja", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string selectedItem = listBox.SelectedItem.ToString();

            // Usuń z jednego lub drugiego repozytorium
            var allFoods = foodRepository.GetAll();
            var foodToRemove = allFoods.FirstOrDefault(f => f.GetDescription() == selectedItem);
            if (foodToRemove != null)
            {
                foodRepository.Delete(foodToRemove.Id);
                foodRepository.Save();
                LoadData();
                return;
            }

            var allDrinks = drinkRepository.GetAll();
            var drinkToRemove = allDrinks.FirstOrDefault(d => d.GetDescription() == selectedItem);
            if (drinkToRemove != null)
            {
                drinkRepository.Delete(drinkToRemove.Id);
                drinkRepository.Save();
                LoadData();
                return;
            }
        }

        private void UpdateTotal()
        {
            decimal total = 0;

            foreach (var item in listBox.Items)
            {
                var line = item.ToString();
                var priceStr = ExtractPrice(line);
                if (decimal.TryParse(priceStr, out decimal price))
                {
                    total += price;
                }
            }

            totalLabel.Text = $"Suma zamówienia: {total:0.00} zł";
        }

        private string ExtractPrice(string text)
        {
            // Próba wyciągnięcia liczby z tekstu, np. "Pizza Margherita - 28,50 PLN"
            var parts = text.Split(' ');
            foreach (var part in parts.Reverse())
            {
                var clean = part.Replace("PLN", "").Replace("zł", "").Replace(",", ".").Trim();
                if (decimal.TryParse(clean, out _))
                {
                    return clean;
                }
            }
            return "0";
        }

        private void FilterComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}