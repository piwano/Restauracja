﻿namespace Core.Models
{
    public class Drink : MenuItem
    {
        public decimal Price { get; set; }
        public bool IsAlcoholic { get; set; }

        public string DisplayText => $"{Name} - {Price:0.00} PLN";

        public override string GetDescription()
        {
            return $"{Name} - {(IsAlcoholic ? "Alcoholic" : "Non-Alcoholic")} - {Price:0.00} PLN";
        }
    }
}
