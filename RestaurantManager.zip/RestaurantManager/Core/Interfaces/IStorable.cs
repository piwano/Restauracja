namespace Core.Interfaces {
    public interface IStorable {
        int Id { get; set; }
    }
}
